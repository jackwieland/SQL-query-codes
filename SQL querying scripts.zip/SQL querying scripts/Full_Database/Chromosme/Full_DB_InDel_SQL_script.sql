-- 1
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr1';

-- 2
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr2';

-- 3
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr3';

-- 4
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr4';

-- 5
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr5';

-- 6
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr6';

-- 7
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr7';

-- 8
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr8';

-- 9
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr9';

-- 10
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr10';

-- 11
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr11';

-- 12
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr12';

-- 13
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr13';

-- 14
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr14';

-- 15
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr15';

-- 16
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr16';

-- 17
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr17';

-- 18
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr18';

-- 19
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr19';

-- 20
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr20';

-- 21
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr21';

-- 22
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chr22';

-- X
SELECT *
FROM InDel_Gene_Files
WHERE Chromosome = 'chrX';

-- Y
SELECT *
FROM InDel_Gene_Files
WHERE Parent_ID IN ('INSERT_ID') AND Chromosome = 'chrY';
-- 1
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr1');

-- 2
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr2');

-- 3
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr3');

-- 4
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr4');

-- 5
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr5');

-- 6
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr6');

-- 7
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr7');

-- 8
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr8');

-- 9
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr9');

-- 10
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr10');

-- 11
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr11');

-- 12
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr12');

-- 13
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr13');

-- 14
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr14');

-- 15
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr15');

-- 16
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr16');

-- 17
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr17');

-- 18
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr18');

-- 19
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr19');

-- 20
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr20');

-- 21
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr21');

-- 22
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chr22');

-- X
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Chromosome IN ('chrX');

-- Y
SELECT DISTINCT *
FROM SNP_Gene_Files
WHERE Parent_ID IN ('INSERT_ID') AND Chromosome = 'chrY';
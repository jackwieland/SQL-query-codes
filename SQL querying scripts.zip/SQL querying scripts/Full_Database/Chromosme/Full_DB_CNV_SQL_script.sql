-- 1
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr1';

-- 2
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr2';

-- 3
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr3';

-- 4
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr4';

-- 5
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr5';

-- 6
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr6';

-- 7
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr7';

-- 8
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr8';

-- 9
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr9';

-- 10
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr10';

-- 11
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr11';

-- 12
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr12';

-- 13
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr13';

-- 14
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr14';

-- 15
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr15';

-- 16
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr16';

-- 17
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr17';

-- 18
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr18';

-- 19
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr19';

-- 20
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr20';

-- 21
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr21';

-- 22
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chr22';

-- X
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Chromosome = 'chrX';

-- Y
SELECT DISTINCT *
FROM CNV_Gene_Files
WHERE Parent_ID IN ('INSERT_ID') AND Chromosome = 'chrY';
-- p36.33
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 1 AND End_Position <= 2300000;

-- p36.32
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 2300001 AND End_Position <= 5400000;

-- p36.31
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 5400001 AND End_Position <= 7200000;

-- p36.23
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 7200001 AND End_Position <= 9200000;

-- p36.22
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 9200001 AND End_Position <= 12700000;

-- p36.21
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 12700001 AND End_Position <= 16200000;

-- p36.13
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 16200001 AND End_Position <= 20400000;

-- p36.12
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 20400001 AND End_Position <= 23900000;

-- p36.11
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 23900001 AND End_Position <= 28000000;

-- p35.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 28000001 AND End_Position <= 30200000;

-- p35.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 30200001 AND End_Position <= 32400000;

-- p35.1
SELECT DISTINCT * 
FROM Patient_ID_File 
WHERE Chromosome = 'chr1' AND Start_Position >= 32400001 AND End_Position <= 34600000;

-- p34.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 34600001 AND End_Position <= 40100000;

-- p34.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 40100001 AND End_Position <= 44100000;

-- p34.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 44100001 AND End_Position <= 46800000;

-- p33
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 46800001 AND End_Position <= 50700000;

-- p32.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 50700001 AND End_Position <= 56100000;

-- p32.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 56100001 AND End_Position <= 59000000;

-- p32.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 59000001 AND End_Position <= 61300000;

-- p31.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 61300001 AND End_Position <= 68900000;

-- p31.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 68900001 AND End_Position <= 69700000;

-- p31.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 69700001 AND End_Position <= 84900000;

-- p22.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 84900001 AND End_Position <= 88400000;

-- p22.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 88400001 AND End_Position <= 92000000;

-- p22.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 92000001 AND End_Position <= 94700000;

-- p21.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 94700001 AND End_Position <= 99700000;

-- p21.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 99700001 AND End_Position <= 102200000;

-- p21.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 102200001 AND End_Position <= 107200000;

-- p13.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 107200001 AND End_Position <= 111800000;

-- p13.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 111800001 AND End_Position <= 116100000;

-- p13.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 116100001 AND End_Position <= 117800000;

-- p12
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 117800001 AND End_Position <= 120600000;

-- p11.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 120600001 AND End_Position <= 121500000;

-- p11.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 121500001 AND End_Position <= 125000000;

-- q11
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 125000001 AND End_Position <= 128900000;

-- q12
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 128900001 AND End_Position <= 142600000;

-- q21.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 142600001 AND End_Position <= 147000000;

-- q21.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 147000001 AND End_Position <= 150300000;

-- q21.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 150300001 AND End_Position <= 155000000;

-- q22
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 155000001 AND End_Position <= 156500000;

-- q23.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 156500001 AND End_Position <= 159100000;

-- q23.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 159100001 AND End_Position <= 160500000;

-- q23.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 160500001 AND End_Position <= 165500000;

-- q24.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 165500001 AND End_Position <= 167200000;

-- q24.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 167200001 AND End_Position <= 170900000;

-- q24.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 170900001 AND End_Position <= 172900000;

-- q25.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 172900001 AND End_Position <= 176000000;

-- q25.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 176000001 AND End_Position <= 180300000;

-- q25.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 180300001 AND End_Position <= 185800000;

-- q31.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 185800001 AND End_Position <= 190800000;

-- q31.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 190800001 AND End_Position <= 193800000;

-- q31.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 193800001 AND End_Position <= 198700000;

-- q32.1
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 198700001 AND End_Position <= 207200000;

-- q32.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 207200001 AND End_Position <= 211500000;

-- q32.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 211500001 AND End_Position <= 214500000;

-- q41
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 214500001 AND End_Position <= 224100000;

-- q42.11
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 224100001 AND End_Position <= 224600000;

-- q42.12
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 224600001 AND End_Position <= 227000000;

-- q42.13
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 227000001 AND End_Position <= 230700000;

-- q42.2
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 230700001 AND End_Position <= 234700000;

-- q42.3
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 234700001 AND End_Position <= 236600000;

-- q43
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 236600001 AND End_Position <= 243700000;

-- q44
SELECT DISTINCT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr1' AND Start_Position >= 243700001 AND End_Position <= 249250621;

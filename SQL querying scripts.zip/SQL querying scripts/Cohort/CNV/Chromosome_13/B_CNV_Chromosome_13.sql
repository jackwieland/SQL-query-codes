-- p13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 1 AND End_Position <= 4500000;

-- p12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 4500001 AND End_Position <= 10000000;

-- p11.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 10000001 AND End_Position <= 16300000;

-- p11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 16300001 AND End_Position <= 17900000;

-- q11
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 17900001 AND End_Position <= 19500000;

-- q12.11
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 19500001 AND End_Position <= 23300000;

-- q12.12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 23300001 AND End_Position <= 25500000;

-- q12.13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 25500001 AND End_Position <= 27800000;

-- q12.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 27800001 AND End_Position <= 28900000;

-- q12.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 28900001 AND End_Position <= 32200000;

-- q13.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 32200001 AND End_Position <= 34000000;

-- q13.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 34000001 AND End_Position <= 35500000;

-- q13.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 35500001 AND End_Position <= 40100000;

-- q14.11
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 40100001 AND End_Position <= 45200000;

-- q14.12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 45200001 AND End_Position <= 45800000;

-- q14.13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 45800001 AND End_Position <= 47300000;

-- q14.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 47300001 AND End_Position <= 50900000;

-- q14.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 50900001 AND End_Position <= 55300000;

-- q21.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 55300001 AND End_Position <= 59600000;

-- q21.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 59600001 AND End_Position <= 62300000;

-- q21.31
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 62300001 AND End_Position <= 65700000;

-- q21.32
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 65700001 AND End_Position <= 68600000;

-- q21.33
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 68600001 AND End_Position <= 73300000;

-- q22.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 73300001 AND End_Position <= 75400000;

-- q22.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 75400001 AND End_Position <= 77200000;

-- q22.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 77200001 AND End_Position <= 79000000;

-- q31.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 79000001 AND End_Position <= 87700000;

-- q31.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 87700001 AND End_Position <= 90000000;

-- q31.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 90000001 AND End_Position <= 95000000;

-- q32.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 95000001 AND End_Position <= 98200000;

-- q32.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 98200001 AND End_Position <= 99300000;

-- q32.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 99300001 AND End_Position <= 101700000;

-- q33.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 101700001 AND End_Position <= 104800000;

-- q33.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 104800001 AND End_Position <= 107000000;

-- q33.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 107000001 AND End_Position <= 110300000;

-- q34
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr13' AND Start_Position >= 110300001 AND End_Position <= 115169878;
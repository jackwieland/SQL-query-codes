-- p13.33
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 1 AND End_Position <= 3300000;

-- p13.32
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 3300001 AND End_Position <= 5400000;

-- p13.31
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 5400001 AND End_Position <= 10100000;

-- p13.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 10100001 AND End_Position <= 12800000;

-- p13.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 12800001 AND End_Position <= 14800000;

-- p12.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 14800001 AND End_Position <= 20000000;

-- p12.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 20000001 AND End_Position <= 21300000;

-- p12.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 21300001 AND End_Position <= 26500000;

-- p11.23
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 26500001 AND End_Position <= 27800000;

-- p11.22
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 27800001 AND End_Position <= 30700000;

-- p11.21
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 30700001 AND End_Position <= 33300000;

-- p11.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 33300001 AND End_Position <= 35800000;

-- q11
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 35800001 AND End_Position <= 38200000;

-- q12
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 38200001 AND End_Position <= 46400000;

-- q13.11
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 46400001 AND End_Position <= 49100000;

-- q13.12
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 49100001 AND End_Position <= 51500000;

-- q13.13
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 51500001 AND End_Position <= 54900000;

-- q13.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 54900001 AND End_Position <= 56600000;

-- q13.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 56600001 AND End_Position <= 58100000;

-- q14.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 58100001 AND End_Position <= 63100000;

-- q14.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 63100001 AND End_Position <= 65100000;

-- q14.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 65100001 AND End_Position <= 67700000;

-- q15
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 67700001 AND End_Position <= 71500000;

-- q21.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 71500001 AND End_Position <= 75700000;

-- q21.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 75700001 AND End_Position <= 80300000;

-- q21.31
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 80300001 AND End_Position <= 86700000;

-- q21.32
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 86700001 AND End_Position <= 89000000;

-- q21.33
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 89000001 AND End_Position <= 92600000;

-- q22
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 92600001 AND End_Position <= 96200000;

-- q23.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 96200001 AND End_Position <= 101600000;

-- q23.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 101600001 AND End_Position <= 103800000;

-- q23.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 103800001 AND End_Position <= 109000000;

-- q24.11
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 109000001 AND End_Position <= 111700000;

-- q24.12
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 111700001 AND End_Position <= 112300000;

-- q24.13
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 112300001 AND End_Position <= 114300000;

-- q24.21
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 114300001 AND End_Position <= 116800000;

-- q24.22
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 116800001 AND End_Position <= 118100000;

-- q24.23
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 118100001 AND End_Position <= 120700000;

-- q24.31
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 120700001 AND End_Position <= 125900000;

-- q24.32
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 125900001 AND End_Position <= 129300000;

-- q24.33
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr12' AND Start_Position >= 129300001 AND End_Position <= 133851895;
-- p22.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 1 AND End_Position <= 2800000;

-- p22.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 2800001 AND End_Position <= 4500000;

-- p22.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 4500001 AND End_Position <= 7300000;

-- p21.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 7300001 AND End_Position <= 13800000;

-- p21.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 13800001 AND End_Position <= 16500000;

-- p21.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 16500001 AND End_Position <= 20900000;

-- p15.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 20900001 AND End_Position <= 25500000;

-- p15.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 25500001 AND End_Position <= 28000000;

-- p15.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 28000001 AND End_Position <= 28800000;

-- p14.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 28800001 AND End_Position <= 35000000;

-- p14.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 35000001 AND End_Position <= 37200000;

-- p14.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 37200001 AND End_Position <= 43300000;

-- p13
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 43300001 AND End_Position <= 45400000;

-- p12.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 45400001 AND End_Position <= 49000000;

-- p12.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 49000001 AND End_Position <= 50500000;

-- p12.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 50500001 AND End_Position <= 54000000;

-- p11.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 54000001 AND End_Position <= 58000000;

-- p11.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 58000001 AND End_Position <= 59900000;

-- q11.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 59900001 AND End_Position <= 61700000;

-- q11.21
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 61700001 AND End_Position <= 67000000;

-- q11.22
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 67000001 AND End_Position <= 72200000;

-- q11.23
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 72200001 AND End_Position <= 77500000;

-- q21.11
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 77500001 AND End_Position <= 86400000;

-- q21.12
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 86400001 AND End_Position <= 88200000;

-- q21.13
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 88200001 AND End_Position <= 91100000;

-- q21.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 91100001 AND End_Position <= 92800000;

-- q21.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 92800001 AND End_Position <= 98000000;

-- q22.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 98000001 AND End_Position <= 103800000;

-- q22.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 103800001 AND End_Position <= 104500000;

-- q22.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 104500001 AND End_Position <= 107400000;

-- q31.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 107400001 AND End_Position <= 114600000;

-- q31.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 114600001 AND End_Position <= 117400000;

-- q31.31
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 117400001 AND End_Position <= 121100000;

-- q31.32
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 121100001 AND End_Position <= 123800000;

-- q31.33
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 123800001 AND End_Position <= 127100000;

-- q32.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 127100001 AND End_Position <= 129200000;

-- q32.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 129200001 AND End_Position <= 130400000;

-- q32.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 130400001 AND End_Position <= 132600000;

-- q33
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 132600001 AND End_Position <= 138200000;

-- q34
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 138200001 AND End_Position <= 143100000;

-- q35
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 143100001 AND End_Position <= 147900000;

-- q36.1
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 147900001 AND End_Position <= 152600000;

-- q36.2
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 152600001 AND End_Position <= 155100000;

-- q36.3
SELECT *
FROM Patient_ID_File
WHERE Chromosome = 'chr7' AND Start_Position >= 155100001 AND End_Position <= 159138663;
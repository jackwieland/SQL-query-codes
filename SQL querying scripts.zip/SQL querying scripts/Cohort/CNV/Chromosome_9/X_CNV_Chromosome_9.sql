-- p24.3
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 1 AND End_Position <= 2200000;

-- p24.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 2200001 AND End_Position <= 4600000;

-- p24.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 4600001 AND End_Position <= 9000000;

-- p23
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 9000001 AND End_Position <= 14200000;

-- p22.3
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 14200001 AND End_Position <= 16600000;

-- p22.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 16600001 AND End_Position <= 18500000;

-- p22.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 18500001 AND End_Position <= 19900000;

-- p21.3
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 19900001 AND End_Position <= 25600000;

-- p21.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 25600001 AND End_Position <= 28000000;

-- p21.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 28000001 AND End_Position <= 33200000;

-- p13.3
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 33200001 AND End_Position <= 36300000;

-- p13.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 36300001 AND End_Position <= 38400000;

-- p13.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 38400001 AND End_Position <= 41000000;

-- p12
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 41000001 AND End_Position <= 43600000;

-- p11.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 43600001 AND End_Position <= 47300000;

-- p11.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 47300001 AND End_Position <= 49000000;

-- q11
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 49000001 AND End_Position <= 50700000;

-- q12
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 50700001 AND End_Position <= 65900000;

-- q13
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 65900001 AND End_Position <= 68700000;

-- q21.11
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 68700001 AND End_Position <= 72200000;

-- q21.12
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 72200001 AND End_Position <= 74000000;

-- q21.13
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 74000001 AND End_Position <= 79200000;

-- q21.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 79200001 AND End_Position <= 81100000;

-- q21.31
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 81100001 AND End_Position <= 84100000;

-- q21.32
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 84100001 AND End_Position <= 86900000;

-- q21.33
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 86900001 AND End_Position <= 90400000;

-- q22.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 90400001 AND End_Position <= 91800000;

-- q22.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 91800001 AND End_Position <= 93900000;

-- q22.31
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 93900001 AND End_Position <= 96600000;

-- q22.32
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 96600001 AND End_Position <= 99300000;

-- q22.33
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 99300001 AND End_Position <= 102600000;

-- q31.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 102600001 AND End_Position <= 108200000;

-- q31.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 108200001 AND End_Position <= 111300000;

-- q31.3
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 111300001 AND End_Position <= 114900000;

-- q32
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 114900001 AND End_Position <= 117700000;

-- q33.1
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 117700001 AND End_Position <= 122500000;

-- q33.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 122500001 AND End_Position <= 125800000;

-- q33.3
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 125800001 AND End_Position <= 130300000;

-- q34.11
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 130300001 AND End_Position <= 133500000;

-- q34.12
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 133500001 AND End_Position <= 134000000;

-- q34.13
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 134000001 AND End_Position <= 135900000;

-- q34.2
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 135900001 AND End_Position <= 137400000;

-- q34.3
SELECT * 
FROM Patient_ID_File
WHERE Chromosome = 'chr9' AND Start_Position >= 137400001 AND End_Position <= 141213431;
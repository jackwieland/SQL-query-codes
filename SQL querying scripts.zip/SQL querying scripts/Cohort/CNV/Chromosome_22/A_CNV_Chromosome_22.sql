-- p13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 1 AND End_Position <= 3800000;

-- p12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 3800001 AND End_Position <= 8300000;

-- p11.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 8300001 AND End_Position <= 12200000;

-- p11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 12200001 AND End_Position <= 14700000;

-- q11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 14700001 AND End_Position <= 17900000;

-- q11.21
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 17900001 AND End_Position <= 22200000;

-- q11.22
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 22200001 AND End_Position <= 23500000;

-- q11.23
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 23500001 AND End_Position <= 25900000;

-- q12.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 25900001 AND End_Position <= 29600000;

-- q12.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 29600001 AND End_Position <= 32200000;

-- q12.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 32200001 AND End_Position <= 37600000;

-- q13.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 37600001 AND End_Position <= 41000000;

-- q13.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 41000001 AND End_Position <= 44200000;

-- q13.31
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 44200001 AND End_Position <= 48400000;

-- q13.32
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 48400001 AND End_Position <= 49400000;

-- q13.33
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr22' AND Start_Position >= 49400001 AND End_Position <= 51304566;
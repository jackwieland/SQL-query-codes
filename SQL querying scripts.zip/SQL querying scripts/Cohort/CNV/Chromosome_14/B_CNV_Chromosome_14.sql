-- p13
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 1 AND End_Position <= 3700000;

-- p12
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 3700001 AND End_Position <= 8100000;

-- p11.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 8100001 AND End_Position <= 16100000;

-- p11.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 16100001 AND End_Position <= 17600000;

-- q11.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 17600001 AND End_Position <= 19100000;

-- q11.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 19100001 AND End_Position <= 24600000;

-- q12
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 24600001 AND End_Position <= 33300000;

-- q13.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 33300001 AND End_Position <= 35300000;

-- q13.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 35300001 AND End_Position <= 36600000;

-- q13.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 36600001 AND End_Position <= 37800000;

-- q21.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 37800001 AND End_Position <= 43500000;

-- q21.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 43500001 AND End_Position <= 47200000;

-- q21.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 47200001 AND End_Position <= 50900000;

-- q22.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 50900001 AND End_Position <= 54100000;

-- q22.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 54100001 AND End_Position <= 55500000;

-- q22.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 55500001 AND End_Position <= 58100000;

-- q23.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 58100001 AND End_Position <= 62100000;

-- q23.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 62100001 AND End_Position <= 64800000;

-- q23.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 64800001 AND End_Position <= 67900000;

-- q24.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 67900001 AND End_Position <= 70200000;

-- q24.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 70200001 AND End_Position <= 73800000;

-- q24.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 73800001 AND End_Position <= 79300000;

-- q31.1
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 79300001 AND End_Position <= 83600000;

-- q31.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 83600001 AND End_Position <= 84900000;

-- q31.3
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 84900001 AND End_Position <= 89800000;

-- q32.11
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 89800001 AND End_Position <= 91900000;

-- q32.12
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 91900001 AND End_Position <= 94700000;

-- q32.13
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 94700001 AND End_Position <= 96300000;

-- q32.2
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 96300001 AND End_Position <= 101400000;

-- q32.31
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 101400001 AND End_Position <= 103200000;

-- q32.32
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 103200001 AND End_Position <= 104000000;

-- q32.33
SELECT DISTINCT *  
FROM Patient_ID_File
WHERE Chromosome = 'chr14' AND Start_Position >= 104000001 AND End_Position <= 107349540;
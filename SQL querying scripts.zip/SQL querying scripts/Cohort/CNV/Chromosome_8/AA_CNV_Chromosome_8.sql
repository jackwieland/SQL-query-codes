-- p23.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 1 AND End_Position <= 2200000;

-- p23.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 2200001 AND End_Position <= 6200000;

-- p23.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 6200001 AND End_Position <= 12700000;

-- p22
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 12700001 AND End_Position <= 19000000;

-- p21.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 19000001 AND End_Position <= 23300000;

-- p21.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 23300001 AND End_Position <= 27400000;

-- p21.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 27400001 AND End_Position <= 28800000;

-- p12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 28800001 AND End_Position <= 36500000;

-- p11.23
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 36500001 AND End_Position <= 38300000;

-- p11.22
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 38300001 AND End_Position <= 39700000;

-- p11.21
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 39700001 AND End_Position <= 43100000;

-- p11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 43100001 AND End_Position <= 45600000;

-- q11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 45600001 AND End_Position <= 48100000;

-- q11.21
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 48100001 AND End_Position <= 52200000;

-- q11.22
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 52200001 AND End_Position <= 52600000;

-- q11.23
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 52600001 AND End_Position <= 55500000;

-- q12.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 55500001 AND End_Position <= 61600000;

-- q12.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 61600001 AND End_Position <= 62200000;

-- q12.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 62200001 AND End_Position <= 66000000;

-- q13.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 66000001 AND End_Position <= 68000000;

-- q13.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 68000001 AND End_Position <= 70500000;

-- q13.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 70500001 AND End_Position <= 73900000;

-- q21.11
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 73900001 AND End_Position <= 78300000;

-- q21.12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 78300001 AND End_Position <= 80100000;

-- q21.13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 80100001 AND End_Position <= 84600000;

-- q21.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 84600001 AND End_Position <= 86900000;

-- q21.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 86900001 AND End_Position <= 93300000;

-- q22.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 93300001 AND End_Position <= 99000000;

-- q22.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 99000001 AND End_Position <= 101600000;

-- q22.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 101600001 AND End_Position <= 106200000;

-- q23.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 106200001 AND End_Position <= 110500000;

-- q23.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 110500001 AND End_Position <= 112100000;

-- q23.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 112100001 AND End_Position <= 117700000;

-- q24.11
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 117700001 AND End_Position <= 119200000;

-- q24.12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 119200001 AND End_Position <= 122500000;

-- q24.13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 122500001 AND End_Position <= 127300000;

-- q24.21
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 127300001 AND End_Position <= 131500000;

-- q24.22
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 131500001 AND End_Position <= 136400000;

-- q24.23
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 136400001 AND End_Position <= 139900000;

-- q24.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr8' AND Start_Position >= 139900001 AND End_Position <= 146364022;
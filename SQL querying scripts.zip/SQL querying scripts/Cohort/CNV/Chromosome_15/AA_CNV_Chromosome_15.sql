-- p13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 1 AND End_Position <= 3900000;

-- p12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 3900001 AND End_Position <= 8700000;

-- p11.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 8700001 AND End_Position <= 15800000;

-- p11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 15800001 AND End_Position <= 19000000;

-- q11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 19000001 AND End_Position <= 20700000;

-- q11.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 20700001 AND End_Position <= 25700000;

-- q12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 25700001 AND End_Position <= 28100000;

-- q13.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 28100001 AND End_Position <= 30300000;

-- q13.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 30300001 AND End_Position <= 31200000;

-- q13.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 31200001 AND End_Position <= 33600000;

-- q14
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 33600001 AND End_Position <= 40100000;

-- q15.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 40100001 AND End_Position <= 42800000;

-- q15.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 42800001 AND End_Position <= 43600000;

-- q15.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 43600001 AND End_Position <= 44800000;

-- q21.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 44800001 AND End_Position <= 49500000;

-- q21.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 49500001 AND End_Position <= 52900000;

-- q21.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 52900001 AND End_Position <= 59100000;

-- q22.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 59100001 AND End_Position <= 59300000;

-- q22.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 59300001 AND End_Position <= 63700000;

-- q22.31
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 63700001 AND End_Position <= 67200000;

-- q22.32
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 67200001 AND End_Position <= 67300000;

-- q22.33
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 67300001 AND End_Position <= 67500000;

-- q23
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 67500001 AND End_Position <= 72700000;

-- q24.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 72700001 AND End_Position <= 75200000;

-- q24.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 75200001 AND End_Position <= 76600000;

-- q24.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 76600001 AND End_Position <= 78300000;

-- q25.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 78300001 AND End_Position <= 81700000;

-- q25.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 81700001 AND End_Position <= 85200000;

-- q25.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 85200001 AND End_Position <= 89100000;

-- q26.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 89100001 AND End_Position <= 94300000;

-- q26.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 94300001 AND End_Position <= 98500000;

-- q26.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr15' AND Start_Position >= 98500001 AND End_Position <= 102531392;
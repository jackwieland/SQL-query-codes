-- p25.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 1 AND End_Position <= 2300000;

-- p25.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 2300001 AND End_Position <= 4200000;

-- p25.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 4200001 AND End_Position <= 7100000;

-- p24.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 7100001 AND End_Position <= 10600000;

-- p24.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 10600001 AND End_Position <= 11600000;

-- p24.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 11600001 AND End_Position <= 13400000;

-- p23
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 13400001 AND End_Position <= 15200000;

-- p22.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 15200001 AND End_Position <= 25200000;

-- p22.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 25200001 AND End_Position <= 27000000;

-- p22.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 27000001 AND End_Position <= 30400000;

-- p21.33
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 30400001 AND End_Position <= 32100000;

-- p21.32
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 32100001 AND End_Position <= 33500000;

-- p21.31
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 33500001 AND End_Position <= 36600000;

-- p21.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 36600001 AND End_Position <= 40500000;

-- p21.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 40500001 AND End_Position <= 46200000;

-- p12.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 46200001 AND End_Position <= 51800000;

-- p12.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 51800001 AND End_Position <= 52900000;

-- p12.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 52900001 AND End_Position <= 57000000;

-- p11.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 57000001 AND End_Position <= 58700000;

-- p11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 58700001 AND End_Position <= 61000000;

-- q11.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 61000001 AND End_Position <= 63300000;

-- q11.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 63300001 AND End_Position <= 63400000;

-- q12
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 63400001 AND End_Position <= 70000000;

-- q13
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 70000001 AND End_Position <= 75900000;

-- q14.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 75900001 AND End_Position <= 83900000;

-- q14.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 83900001 AND End_Position <= 84900000;

-- q14.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 84900001 AND End_Position <= 88000000;

-- q15
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 88000001 AND End_Position <= 93100000;

-- q16.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 93100001 AND End_Position <= 99500000;

-- q16.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 99500001 AND End_Position <= 100600000;

-- q16.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 100600001 AND End_Position <= 105500000;

-- q21
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 105500001 AND End_Position <= 114600000;

-- q22.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 114600001 AND End_Position <= 118300000;

-- q22.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 118300001 AND End_Position <= 118500000;

-- q22.31
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 118500001 AND End_Position <= 126100000;

-- q22.32
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 126100001 AND End_Position <= 127100000;

-- q22.33
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 127100001 AND End_Position <= 130300000;

-- q23.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 130300001 AND End_Position <= 131200000;

-- q23.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 131200001 AND End_Position <= 135200000;

-- q23.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 135200001 AND End_Position <= 139000000;

-- q24.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 139000001 AND End_Position <= 142800000;

-- q24.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 142800001 AND End_Position <= 145600000;

-- q24.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 145600001 AND End_Position <= 149000000;

-- q25.1
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 149000001 AND End_Position <= 152500000;

-- q25.2
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 152500001 AND End_Position <= 155500000;

-- q25.3
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 155500001 AND End_Position <= 161000000;

-- q26
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 161000001 AND End_Position <= 164500000;

-- q27
SELECT DISTINCT *
FROM Patient_ID_File
WHERE Chromosome = 'chr6' AND Start_Position >= 164500001 AND End_Position <= 171115067;